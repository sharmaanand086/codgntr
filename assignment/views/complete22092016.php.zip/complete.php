<?php include( 'header.php');?>
<?php include( 'top_menubar.php');?>
<?php include( 'middle_navigation_bar.php');?>

<?php
$cookie_name = "anyname";
$cookie_value = "anycontent";
$checknum=0;

?>

<style>
.inner1 {
    color: #000;
    display:inline-block;
    text-align: center;
    border: 3px dashed #696969;
    border-radius: 10px;
    padding: 50px 110px 30px;
    //margin-left: 385px;
}
.drop_box{
    width: 400px;
    height: 290px;
    margin: auto;
    position:relative;
    bottom : 350px;
    text-align : center;
}
.form-group a{
 position:relative;
    bottom : 50px;
 text-decoration:none;
left : 270px;

}
</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<!--<script type="text/javascript" src="<?=base_url('assets/js/jquery.slimscroll.js');?>"> </script>-->
<script type="text/javascript" src="<?=base_url('assets/js/jquery.slimscroll2.js');?>"> </script>
<!--<script src="<?=base_url('assets/js/uploading.js');?>"></script>-->
<script>
    $(document).ready(function(){

     $(window).load(function() {
         $(".loader").fadeOut("slow");
         });
        
        $(".assignsubmit").click(function(){
             var id = $(this).attr('id');
           var act= $(".changeaction").attr('id');
              //alert(act);
         if(act==0){
                     $("#myform").attr("action", "editsolution/" + id);
                     
                      $("#myModal").modal('show');
            
             }else{
             
                 $("#myform").attr("action",id);
                 $("#myModal").modal('show');
             }
         })  
         
           $('#solutionfile').change(function() {
                 // alert('file is submitted');
              $("#myform").submit();
              
          });

    var ffsize=$(".filesize").attr('id');
   //alert(ffsize);

  
   var xyz=  $(".change123").attr('id');
   //alert(xyz);
   var xyz1='#'+xyz;
   if(ffsize > 0)
   {
      
      $(".latest_assi-cmp_wrapp").css({
                            //"background": "#a5bd52",
                         "display":"none",
                            });
      var b=  $(".changecol").attr('id'); 
                     // alert(b);
                      var bb1='#'+b;
                     //$(bb1).not(this).hide();
                     
                     //alert(bb1);
                     $(bb1).css({
                           // "background": "#a5bd52",
                            "display":"block",
                             });

   }
 

         
         var c=ffsize/100;
   var progression = 0,
    progress = setInterval(function() 
    {
        $('#progress1 .progress-text').text((progression*c) + 'kb /'+ffsize+'kb');

        $('#progress1 .progress-bar').css({'width':progression+'%'});
        if(progression == 100) {
            clearInterval(progress);
             $(".row123").hide();
             $(".latest_assi-cmp_wrapp").css({
                            //"background": "#a5bd52",
                         "display":"block",
                            });
          } else
          progression += 10; 
       
    }, 500);
        
          
     });
</script>
<script>
    
</script>
<?php //echo  $nnoofassignment;
 ?>
<div class="loader" style="position:fixed;left: 0px;top: 0px;width: 100%;height: 100%;z-index: 9999;background: url('http://smbseminar.com/assignment/assets/images/preloader.gif') 50% 50% no-repeat #fff;">
  </div>


  <div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
        
            <div class="modal-body">
             
               <form action="" id="myform" method="post" enctype="multipart/form-data">
                          
                   
                  
                      <div class="form-group">
                          <label></label>

                          <input type="file" name="solutionfile" id="solutionfile" class="form-control" style="width: 400px; height: 400px; margin:auto;border: 3px dashed #696969; background: url('http://smbseminar.com/assignment/assets/images/latest/Untitled-2.png'); background-repeat: no-repeat; background-position: center; cursor: pointer;" value="">
<a href="">cancel</a>

                          <!--<div class="drop_box">
                           <img src="<?=base_url('assets/images/latest/Drag_Drop_icon.png');?>" alt="">                        
                           <h1>drag and drop</h1>
                           <p>your assignment file here, or browse</p>
                           <a href="">cancel</a>
                        </div> -->

                      </div>
                        
                 </form>
                  
                  
            </div>
            <div class="modal-footer"> 
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <!-- <button  id="uploadbutton" type="submit" class="btn btn-primary">Save changes</button>-->                
            </div>
        </div>
    </div>
</div>
<?php   $fisttime=$_SESSION['firsttime'];
   $contactid= $_SESSION['contid'];
//var_dump($noofassignment);
//var_dump($complete);echo "<br>";

//var_dump($submitted);
//echo $noofassignment;
 ?>
<?php if($fisttime==0){?>
  <?php if($noofassignment==0){?>
 <section class="latest-assi" id="latest-assi1">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 upload_view">
                <div class=" col-xs-12 assi-cmp-bg" style="border-radius: 10px;">
                    <div class="assi_pull-left">
                        <img class="img-responsive" src="<?=base_url('assets/images/latest/Assignment_Complete_Icon.png');?>">
                    </div>
                    <div class="latest_assi-body" style="position:relative;top:30px;">
                        <div class="latest_assi-cpm_heading">
                            <h1> Write Your Name & Objective</h1>
                            
                        </div>
                        <div class="ass-cmp_objective">
                            <p>Completed assignments turn green. Once complete, you can view them or edit them to remove or add files.
                        </div>

                        <!--<div class="btn_cmp_inline ">
                            <a class="btn_view_wrap btn-cmp-view" style="cursor: pointer;" data-lead-id="banner-btn"> View </a>
                        </div>
                        <div class="btn_cmp_inline ">
                            <a class="btn_view_wrap btn-cmp-view" style="cursor: pointer;" data-lead-id="banner-btn"> Edit </a>
                        </div>
                        <div class="ass_complete-view">
                           <img src="<?=base_url('assets/images/latest/Completion_Status.png');?>" alt="" >
                            <p>Completed on time</p>
                        </div>-->
                    </div>
                </div>
            </div>
        </div>

      
<div class="row" id="hide-tooltip">
            <div class="col-xs-12 hint-assi_complete">
                    <div class="urgent_hint_arrow">
                        <img src="<?=base_url('assets/images/latest/left_up_arrow.png');?>" alt="">
                    </div>
                    <div class="hints-box already_cmp">
                        <div class="hint-bulp">
                            <img src="<?=base_url('assets/images/latest/bulp.png');?>" alt="">
                        </div>
                        <div class="hint-cancel">
                            <p>Since you’ve completed a task already, it’s listed in this tab</span> 
                            </p>
                            <img src="<?=base_url('assets/images/latest/cross.png');?>" alt="" id="close-tab" onClick="SetCookie('anyname','anycontent','-1')">
                           
                       </div>                  
                    </div>
            </div>
        </div>
</section>
<?php }else{ ?>
 <section class="latest-assi" id="latest-assi2">
    <div class="jklnoofassign" id="<?php echo $nnoofassignment; ?>"></div>
    <div class="container-fluid">
      <?php 
      
foreach($name as $row1){
           $nameuser=$row1->name;
 }
 //echo  $nameuser;
?>
       
     <?php //var_dump($overdue);
?>
     <?php  //echo  $assignmentno;
 //echo "<br>"; 
 //echo  $filesize; 
?>
     <?php $kbdata=1024;
        
         $currentfile=intval($filesize/$kbdata);?>
     
     <?php  foreach ($assignment as $row){
              
                 $update=$row->udate;
                 $sudate=$row->subdate;
              
              $date = date_create($update);
              $date1= date_create($sudate);
              //var_dump($date);var_dump($date1);
              // echo  $date;//echo"<br>";//echo  $date1;//echo"<br>";
             
                  
                   $assigno= $row->aid;
              foreach ($complete as $row1){
                      $newassigno=$row1->assignment_no;
                          if($newassigno== $assigno){
                          
                                 $newstatus=$row1->status;
                                  if($newstatus==1) {
                                     //echo $newassigno;
               ?>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 upload_view">
                 
                <div class=" col-xs-12 latest_assi-cmp_wrapp" id="<?php echo "a$row->aid"; ?>">
                    <div class="assi_pull-left">
                        <img class="img-responsive" src="<?=base_url('assets/images/latest/Assignment_Complete_Icon.png');?>">
                    </div>
                    <div class="latest_assi-body">
                        <div class="latest_assi-cpm_heading">
                       
                            <h1><?php echo "$row->aid";?>.<?php echo "$row->name";?></h1>
                           <!-- <p>3<sup style="font-size: 12px;">rd</sup> June, 2016</p>-->
                            <p><?php echo date_format( $date , 'jS F, Y');?></p>
                        </div>
                        <div class="ass-cmp_objective">
                            <p><?php echo "$row->discription";?> click <span style="font-family: 'MyriadPro-Bold';">“Edit”</span> button below & upload
                                your file. You can also see <span style="font-family: 'MyriadPro-Bold';">“View Reference”</span> for an example.</p>
                        </div>

                        <div class="changeaction" id="<?php echo $assignmentno; ?>"></div>
                        
                        <div class="btn_cmp_inline ">
  <!-- <a href="<?php echo  base_url()."uploads/2_assignment/$row->file";?>" target="_blank" class="btn_view_wrap btn-cmp-view" data-lead-id="banner-btn">View</a>-->
<?php  foreach ($submitted as $row123){ 
                   $newassignmentnno=$row123->aid;
                   $currentiid=$row->aid;
                   $ccconid=$row123->contactid;
                   // var_dump( $newassignmentnno);
                   if(($newassignmentnno==$currentiid)&&($contactid==$ccconid)){
                  // echo "<br>"; echo $newassignmentnno;
        ?>
         <a href="<?php echo  base_url()."uploads/2_submission/$row123->file";?>" target="_blank" class="btn_view_wrap btn-cmp-view" data-lead-id="banner-btn">View</a>
         <?php  }
          } ?>
                        </div>
                       
                        <div class="btn_cmp_inline ">
                               <!-- <a href="#<?php //echo base_url()."newuser/do_upload/".$row->aid;?>" name="submit" id="<?php //echo $row->aid; ?>" class="assignsubmit gotitbtn btngotit-inline" data-lead-id="banner-btn"> Submit </a>-->
   <a href="#<?php //echo base_url()."newuser/do_upload/".$row->aid;?>" name="submit" id="<?php echo $row->aid; ?>"class=" assignsubmit btn_view_wrap btn-cmp-view" data-lead-id="banner-btn"> Edit </a>
                        </div>
                 <?php  $rownumber=$row->aid;?>
     
  <?php if( (($assignmentno>0)&&($filesize>0))&&($rownumber==$assignmentno) ){ ?>
                      <div class="changecol" id="<?php echo "a$row->aid"; ?>"></div>
                    <div class="row123">      
                        <div class="col-xs-12 col-sm-12 progress-container">
                                 
                              <div id="progress1" class="progress1" style="position: relative;width:250px;height:20px;border:1px solid red;top:180px">
                            <span class="progress-text" style=" position: absolute;z-index:2;bottom:155px;"></span>
                      <div class="progress-bar"   style="height: 15px;width:0%;display: inline-block;position: relative;bottom: 173px;border-radius: 25px;background: green;"> 
                        </div>
                    </div>     
           <div class="filesize" id="<?php echo"$currentfile"?>"> </div>
                 
                          
                         </div>
                      </div>   
                        <?php }?>
                        <?php foreach($overdue as $row3){
                                                             $abcno=$row3->assignment_no;
                                                           
                                                                  if($abcno==$assigno){
                                              
                                                             $newcheck=$row3->overdue;
                                                               if($newcheck==0){
                                                               // echo "$row3->overdue";echo "<br>";
                                                               
                       ?>
                                                                               
                       <div class="ass_complete-view">
                            <img src="<?=base_url('assets/images/latest/Completion_Status.png');?>" alt="">
                            <p>Completed on time</p>
                        </div>
                              <?php                             
                                                                     }else{?>
                           <div class="ass_complete-view">
                            <img src="<?=base_url('assets/images/latest/Completion_Status.png');?>" alt="">
                            <p>Completed After Duedate</p>
                        </div>
                                                                             

                       <?php
                                               // echo "$row3->overdue";echo "<br>";
                                                                            
                                                                           }
                                                                     
                                                      }   }
                         ?>
                        <!--<div class="ass_complete-view">
                            <img src="<?=base_url('assets/images/latest/Completion_Status.png');?>" alt="">
                            <p>Completed on time</p>
                        </div>-->
                  
                    </div>
                    
                </div>
            </div>
          
        </div>
         <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class=" col-xs-12 user-comments" id="<?php echo "c$row->aid"; ?>">
                    <h1 class="flip"  id="<?php echo "$row->aid"; ?>">Comments<img style="width: 30px;" src="<?=base_url('assets/images/latest/down.png');?>"</h1>
                    <button type="button" class="btn1 btn-box-tool" id="cancel_content" data-widget="remove"><i class="fa fa-times"></i>
                    </button>
                </div>
            </div>
        </div>
        <!--------------------------------- hide section ---------------------------------!-->
        <div class="panel" id="<?php echo "b$row->aid"; ?>">
            <div class="row">
                <div class="col-lg-12 col-md-1col-md-11  col-sm-12 col-xs-12 ">
                    <div class="col-xs-12  comment-here">
                        <form name="form1">
                            <div class="input-area">
<input type="text" id="uname" name="uname" style="display:none;" value="<?php echo  $nameuser; ?>"  disabled /><br>
                               <!-- <input type="text" id="uname" name="uname" value=""  />-->
                                <input type="text" class="addinput_controls search" name ="<?php echo $row->aid;?>" id="msg<?php echo $row->aid;?>" placeholder="Type your comment here. Press enter to  post">
                                    <!--<input type="text" class="addinput_controls search" name ="msg" id="msg" placeholder="Type your comment here. Press enter to  post">-->
                                        <!-- <a href="#" onclick="submitChat()">send</a> -->
                                 <span class="glyphicon glyphicon-paperclip "></span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row main-cmments">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
                    <div class="col-xs-12 post-cmnt">
                        <div class="chat_process" id="chat_process<?php echo $row->aid;?>">
                               
                        </div>
                    </div>
                </div>
            </div>
        </div>
          <?php  
                   } 
                 }
                }
               }?>
        <div class="row" id="hide-tooltip">
            <div class="col-xs-12 hint-assi_complete">
                    <div class="urgent_hint_arrow">
                        <img src="<?=base_url('assets/images/latest/left_up_arrow.png');?>" alt="">
                    </div>
                    <div class="hints-box already_cmp">
                        <div class="hint-bulp">
                            <img src="<?=base_url('assets/images/latest/bulp.png');?>" alt="">
                        </div>
                        <div class="hint-cancel">
                            <p>Since you’ve completed a task already, it’s listed in this tab</span> 
                            </p>
                            <img src="<?=base_url('assets/images/latest/cross.png');?>" alt="" id="close-tab" onClick="SetCookie('anyname','anycontent','-1')">
                           
                       </div>                  
                    </div>
            </div>
        </div>
    </div>
</section>
<?php }?>
<?php }else{?>
  <?php if($noofassignment==0){ ?>
   <section class="latest-assi" id="latest-assi1">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 upload_view">
                <div class=" col-xs-12 assi-cmp-bg" style="border-radius: 10px;">
                    <div class="assi_pull-left">
                        <img class="img-responsive" src="<?=base_url('assets/images/latest/Assignment_Complete_Icon.png');?>">
                    </div>
                    <div class="latest_assi-body" style="position:relative;top:30px;">
                        <div class="latest_assi-cpm_heading">
                            <h1> Write Your Name & Objective</h1>
                            
                        </div>
                        <div class="ass-cmp_objective">
                            <p>Completed assignments turn green. Once complete, you can view them or edit them to remove or add files.
                        </div>

                        <!--<div class="btn_cmp_inline ">
                            <a class="btn_view_wrap btn-cmp-view" style="cursor: pointer;" data-lead-id="banner-btn"> View </a>
                        </div>
                        <div class="btn_cmp_inline ">
                            <a class="btn_view_wrap btn-cmp-view" style="cursor: pointer;" data-lead-id="banner-btn"> Edit </a>
                        </div>
                        <div class="ass_complete-view">
                           <img src="<?=base_url('assets/images/latest/Completion_Status.png');?>" alt="">
                            <p>Completed on time</p>
                        </div>-->
                    </div>
                </div>
            </div>
        </div>

      

</section>
  <?php }else{?>
      

<section class="latest-assi" id="latest-assi2">
    <div class="jklnoofassign" id="<?php echo $nnoofassignment;?>"></div>
    <div class="container-fluid">
      <?php 
      
foreach($name as $row1){
           $nameuser=$row1->name;
 }
 //echo  $nameuser;
?>
       
     <?php //var_dump($overdue);?>
     <?php  //echo  $assignmentno; //echo "<br>";  //echo  $filesize; ?>
     <?php $kbdata=1024;
        
         $currentfile=intval($filesize/$kbdata);?>
     
     <?php  foreach ($assignment as $row){
              
                 $update=$row->udate;
                 $sudate=$row->subdate;
              
              $date = date_create($update);
              $date1= date_create($sudate);
              //var_dump($date);var_dump($date1);
              // echo  $date;//echo"<br>";//echo  $date1;//echo"<br>";
             
                  
                   $assigno= $row->aid;
              foreach ($complete as $row1){
                      $newassigno=$row1->assignment_no;
                          if($newassigno== $assigno){
                          
                                 $newstatus=$row1->status;
                                  if($newstatus==1) {
                                   //  echo $newassigno;
               ?>
        <div class="row amitsir" id="<?php echo "i$row->aid"; ?>">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 upload_view">
                 
                <div class=" col-xs-12 latest_assi-cmp_wrapp" id="<?php echo "a$row->aid"; ?>">
                    <div class="assi_pull-left">
                        <img class="img-responsive" src="<?=base_url('assets/images/latest/Assignment_Complete_Icon.png');?>">
                    </div>
                    <div class="latest_assi-body">
                        <div class="latest_assi-cpm_heading">
                       
                            <h1><?php echo "$row->aid";?>.<?php echo "$row->name";?></h1>
                           <!-- <p>3<sup style="font-size: 12px;">rd</sup> June, 2016</p>-->
                            <p><?php echo date_format( $date , 'jS F, Y');?></p>
                        </div>
                        <div class="ass-cmp_objective">
                            <p><?php echo "$row->discription";?> click <span style="font-family: 'MyriadPro-Bold';">“Edit”</span> button below & upload
                                your file. You can also see <span style="font-family: 'MyriadPro-Bold';">“View Reference”</span> for an example.</p>
                        </div>

                        <div class="changeaction" id="<?php echo $assignmentno; ?>"></div>
                        
                        <div class="btn_cmp_inline ">
   <!--<a href="<?php echo  base_url()."uploads/2_assignment/$row->file";?>" target="_blank" class="btn_view_wrap btn-cmp-view" data-lead-id="banner-btn">View</a>-->
        <?php  foreach ($submitted as $row123){ 
                   $newassignmentnno=$row123->aid;
                   $currentiid=$row->aid;
                   if( $newassignmentnno==$currentiid){
        ?>
         <a href="<?php echo  base_url()."uploads/2_submission/$row123->file";?>" target="_blank" class="btn_view_wrap btn-cmp-view" data-lead-id="banner-btn">View</a>
         <?php  }
          } ?>
                        </div>
                       
                        <div class="btn_cmp_inline ">
                               <!-- <a href="#<?php //echo base_url()."newuser/do_upload/".$row->aid;?>" name="submit" id="<?php //echo $row->aid; ?>" class="assignsubmit gotitbtn btngotit-inline" data-lead-id="banner-btn"> Submit </a>-->
   <a href="#<?php //echo base_url()."newuser/do_upload/".$row->aid;?>" name="submit" id="<?php echo $row->aid; ?>"class=" assignsubmit btn_view_wrap btn-cmp-view" data-lead-id="banner-btn"> Edit </a>
                        </div>
                 <?php  $rownumber=$row->aid;?>
     
  <?php if( (($assignmentno>0)&&($filesize>0))&&($rownumber==$assignmentno) ){ ?>
                      <div class="changecol" id="<?php echo "a$row->aid"; ?>"></div>
                    <div class="row123">      
                        <div class="col-xs-12 col-sm-12 progress-container">
                                 
                              <div id="progress1" class="progress1" style="position: relative;width:250px;height:20px;border:1px solid red;top:180px">
                            <span class="progress-text" style=" position: absolute;z-index:2;bottom:155px;"></span>
                      <div class="progress-bar"   style="height: 15px;width:0%;display: inline-block;position: relative;bottom: 173px;border-radius: 25px;background: green;"> 
                        </div>
                    </div>     
           <div class="filesize" id="<?php echo"$currentfile"?>"> </div>
                 
                          
                         </div>
                      </div>   
                        <?php }?>
                        <?php foreach($overdue as $row3){
                                                             $abcno=$row3->assignment_no;
                                                           
                                                                  if($abcno==$assigno){
                                              
                                                             $newcheck=$row3->overdue;
                                                               if($newcheck==0){
                                                               // echo "$row3->overdue";echo "<br>";
                                                               
                       ?>
                                                                               
                       <div class="ass_complete-view">
                            <img src="<?=base_url('assets/images/latest/Completion_Status.png');?>" alt="">
                            <p>Completed on time</p>
                        </div>
                              <?php                             
                                                                     }else{?>
                           <div class="ass_complete-view">
                            <img src="<?=base_url('assets/images/latest/Completion_Status.png');?>" alt="">
                            <p>Completed After Duedate</p>
                        </div>
                                                                             

                       <?php
                                               // echo "$row3->overdue";echo "<br>";
                                                                            
                                                                           }
                                                                     
                                                      }   }
                         ?>
                        <!--<div class="ass_complete-view">
                            <img src="<?=base_url('assets/images/latest/Completion_Status.png');?>" alt="">
                            <p>Completed on time</p>
                        </div>-->
                  
                    </div>
                    
                </div>
            </div>
          
        </div>
         <div class="row amitsir" id="<?php echo "ia$row->aid"; ?>" >
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class=" col-xs-12 user-comments" id="<?php echo "c$row->aid"; ?>">
                 <h1><span id="count<?php echo $row->aid;?>" style="color:#fff;"></span></h1>
                    <h1 class="flip bottom-hide<?php echo "$row->aid"; ?>"  id="<?php echo "$row->aid"; ?>">Comments</h1>
            
                    <h1 class="flip bottom-show<?php echo "$row->aid"; ?>" style="color:white;display:none;" id="<?php echo "$row->aid"; ?>"> New Comments <span style="color:#6d6d6d;">(Click to Open)</span></h1>
                      
                    <button type="button" class="btn1 btn-box-tool" id="cancel_content" data-widget="remove"><i class="fa fa-times"></i>
                    </button>
                </div>
            </div>
        </div>
        <!--------------------------------- hide section ---------------------------------!-->
        <div class="panel" id="<?php echo "b$row->aid"; ?>">
            <div class="row">
                <div class="col-lg-12 col-md-1col-md-11  col-sm-12 col-xs-12 ">
                    <div class="col-xs-12  comment-here">
                        <form name="form1">
                            <div class="input-area">
<input type="text" id="uname" name="uname" style="display:none;" value="<?php echo  $nameuser; ?>"  disabled /><br>
                               <!-- <input type="text" id="uname" name="uname" value=""  />-->
                                <input type="text" class="addinput_controls search" name ="<?php echo $row->aid;?>" id="msg<?php echo $row->aid;?>" placeholder="Type your comment here. Press enter to  post">
                                    <!--<input type="text" class="addinput_controls search" name ="msg" id="msg" placeholder="Type your comment here. Press enter to  post">-->
                                        <!-- <a href="#" onclick="submitChat()">send</a> -->
                                 <span class="glyphicon glyphicon-paperclip "></span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row main-cmments">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
                    <div class="col-xs-12 post-cmnt">
                        <div class="chat_process" id="chat_process<?php echo $row->aid;?>">
                               
                        </div>
                    </div>
                </div>
            </div>
        </div>
          <?php  
                   } 
                 }
                }
               }?>
        
</section>
     <?php } ?>
<?php } ?>

<?php

if(!isset($_COOKIE[$cookie_name])) {
	
    
} else {
	
    ?>
    <script type="text/javascript">
    $("#hide-tooltip").css({

    	'display':'none',

    });
</script>
    <?php
   
}
?>

<script type="text/javascript">
    $(document).ready(function() {
    $(".bhavesh").addClass('active');
    $(".trd").addClass('active');

});
</script>
<script type="text/javascript">
   $("#close-tab").click(function (e) {
   $("#hide-tooltip").hide('slow');
   //$("#latest-up").css('margin-top','35px');
    
   
});

</script>
<script>
    // $(document).ready(function() {
    //     $("#flip").click(function() {
    //         $("#panel").slideToggle("slow");
    //        $('.user-comments').css("border-radius","0px 0px 0px 0px");
    //        //$('#cancel_content').css("display","block");
    //     });
    // });

$(document).ready(function(){
           var ttchange=0;
    $(".flip").click(function(){
        ttchange=ttchange+1;
       var same_id=$(this).attr('id');
       comment_buuton='#'+same_id;
       //alert(comment_buuton);
       var hideshow='#i'+same_id;
       var hideshow1='#ia'+same_id;
       if(ttchange==1){
                                //alert('this is for first');
                                $(".amitsir").hide();
                                $(hideshow).show();
                                $(hideshow1).show();
                                
                              
                            }
              if(ttchange==2){
                              // alert('this is second');
                               $(".amitsir").show();
                               ttchange=0;
                             }
       //alert(comment_buuton);

       var b_val='b'+same_id;
       var panel_val='#'+b_val;
       //alert(panel_val);
       //var same_id12=1;
        getChangeStatus(same_id);
         
       //var c_val=''+same_id;
       //var user-comments_val='#'+c_val;
       //alert(user-comments_val);

       $(panel_val).slideToggle(500);
       $(panel_val).toggleClass("main");
        //$('.user-comments').css("border-radius","0px 0px 0px 0px");
        $("#cancel_content").toggleClass("main");
        //$('.user-comments').css("border-radius","0px 0px 10px 10px");
        //$('.user-comments').css("border-radius","0px 0px 0px 0px");
        $('.user-comments').toggleClass("main1");
       
             setInterval(function(){ 
           getSuccessmessage(same_id);
        }, 500);
    });
    
       
       //alert(same_id);

           var chenoass=$('.jklnoofassign').attr('id');
       //for(var same_id=1;same_id <=chenoass;same_id++){
         //  getCountmessage(same_id);
         //  getSuccessmessage(same_id);
         // } 
        
       setInterval(function(){ 
           for(var same_id=1;same_id <=chenoass;same_id++){
           getCountmessage(same_id);
          } 
        },2000);
        
     //var id1=1;
     //setInterval(function(){ 
      //for(id1;id1<10;id1++){
           //getCountmessage(id1);
           // }
     //},500);
});

$(document).ready(function(){
    $("#cancel_content").click(function(){

       $(".panel").slideUp(500);
        $("#cancel_content").toggleClass("main");
        $(".user-comments").toggleClass("main1");

    });
});


 $(document).ready(function() {
    $(".strong_active").addClass('active');
    $(".trd").addClass('active');

});
</script>
<script type="text/javascript">

$("input").on("keydown",function search(e) {

    if(e.keyCode == 13) {
         var id1 = $(this).attr('name');
          //alert(id1);
         getSuccessOutput(id1);
         
   // submitChat();
     document.getElementById('msg'+id1).value = "";

    }

});

function getSuccessOutput(id1) {
          // alert(id1);
    $.ajax({
           "url": "<?php echo site_url('newuser/chat')?>",
           "type": "POST",
           data: {msg: $("#msg"+id1).val(),name: $("#uname").val(),id:id1},
           dataType: "text",  
            cache:false,
         complete: function (response) {
           // $('#output').html(response.responseText);
           // alert('this is complete !!');
        },
        success :  function (result) {
           // $('#output').html('Bummer: there was an error!');
               //$('#chat_process').html(result);
              getSuccessmessage();
          // alert('success in called !!');
        },

        error: function () {
           // $('#output').html('Bummer: there was an error!');
          // alert('errore !!');
        },
    });
    return false;
}
function getSuccessmessage(id1) {
    $.ajax({
           "url": "<?php echo site_url('newuser/chat_message')?>",
           "type": "POST",
           data: {msg: $("#msg").val(),name: $("#uname").val(),id:id1},
           dataType: "text",  
            cache:false,
         complete: function (response) {
           // $('#output').html(response.responseText);
           // alert('this is complete111 !!');
        },
        success :  function (result) {
           // $('#output').html('Bummer: there was an error!');
               $('#chat_process'+id1).html(result);
          // alert('success in called11111 !!');
        },

        error: function () {
           // $('#output').html('Bummer: there was an error!');
          // alert('errore1111 !!');
        },
    });
    return false;
}
function getChangeStatus(id1) {
    $.ajax({
           "url": "<?php echo site_url('newuser/Notification_message')?>",
           "type": "POST",
           data: {id:id1},
           dataType: "text",  
            cache:false,
         complete: function (response) {
           // $('#output').html(response.responseText);
           // alert('this is complete111 !!');
        },
        success :  function (result) {
           // $('#output').html('Bummer: there was an error!');
               //$('#chat_process'+id1).html(result);
          // alert('success in called11111 !!');
        },

        error: function () {
           // $('#output').html('Bummer: there was an error!');
          // alert('errore1111 !!');
        },
    });
    return false;
}
function getCountmessage(id1) {
    $.ajax({
           "url": "<?php echo site_url('newuser/Notification_Count')?>",
           "type": "POST",
           data: {id:id1},
           dataType: "text",  
            cache:false,
         complete: function (response) {
           // $('#output').html(response.responseText);
           // alert('this is complete111 !!');
        },
        success :  function (result) {
           // $('#output').html('Bummer: there was an error!');
               
               //console.log(result);
               if ($(".main").is(':visible')){
                    // var id1=$(this).attr('class');
                       //alert(id1);  
                     //getChangeStatus(id1);
                   $('#count'+id1).html(result);
                  $('#count'+id1).hide();
                  $('.bottom-hide'+id1).show(); 
                  $('.bottom-show'+id1).hide();
                  $('#c'+id1).css({'background-color': '#fff'});
 
                    }
              else{
              if(result==0)
             {
                //its 0 comments than no display
                //alert(result+''+id1);
                  $('#count'+id1).html(result);
                  $('#count'+id1).hide();
                  $('.bottom-hide'+id1).show(); 
                  $('.bottom-show'+id1).hide();
                  $('#c'+id1).css({'background-color': '#fff'});
             }else{ 
                  //its more comments than no display
                  //alert(result+''+id1);
                   $('#count'+id1).show();
                   $('#count'+id1).html(result);
                  $('.bottom-hide'+id1).hide(); 
                  $('.bottom-show'+id1).show();
                  $('#c'+id1).css({'background-color': '#000'});
                  }
              }
               
          // alert('success in called11111 !!');
        },

        error: function () {
           // $('#output').html('Bummer: there was an error!');
          // alert('errore1111 !!');
        },
    });
    return false;
}


 //setInterval(function(){ 
      //     getSuccessmessage();
        //}, 1000);
</script>
<script type="text/javascript">
    $(function(){
      $('.chat_process').slimscroll({
        height: '388px'
      }).parent().css({
        background: '#237FAD',
        border: '2px dashed #184055'
      });


    });
</script>
<script>
$(document).ready(function(){
  var $content = $(".content").hide();
  var $content1 = $("#aa").hide();
  $(".toggle").on("click", function(e){
    $(this).toggleClass("expanded");
    $content.slideToggle();
    $content1.slideToggle();
  });
});
</script>

<script>
    function SetCookie(c_name,value,expiredays)
        {
            var exdate=new Date()
            exdate.setDate(exdate.getDate()+expiredays)
            document.cookie=c_name+ "=" +value+
            ((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
    		//location.reload()
        }
    </script>