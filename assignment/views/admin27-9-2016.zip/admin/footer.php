<!--<script src="<?= base_url('assets/admin_design/js/jquery.js');?>"></script>-->
<!-- Bootstrap Core JavaScript -->






<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>-->
<!-- <script src="js/script.js"></script> -->
<!-- <script src="js/index.js"></script> -->
<!-- <script src="js/changepassword.js"></script> -->
<!-- <script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places"></script> -->
<!--<script src="<?=base_url('assets/admin_design/js/jquery.nicescroll.min.js');?>" type="text/javascript"></script>-->


<script src="<?=base_url('assets/admin_design/js/jquery-1.10.2.js');?>" type="text/javascript"></script>
<script src="<?=base_url('assets/admin_design/js/jquery1.js');?>" type="text/javascript"></script>
<script src="<?= base_url('assets/admin_design/js/bootstrap.min.js');?>"></script>



</body>
</html>