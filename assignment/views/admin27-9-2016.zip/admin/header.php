<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<title> Speak To A Fortune </title>
		
		<!-- Bootstrap Core CSS -->
		<link href="<?=base_url('assets/admin_design/css/bootstrap.min.css');?>" rel="stylesheet">
		<link href="<?=base_url('assets/admin_design/css/bootstrap.css');?>" rel="stylesheet"> 

		<!-- Custom Fonts -->
		<link href="<?=base_url('assets/admin_design/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">
		<!-- Custom CSS -->

		<link rel="stylesheet" href="<?=base_url('assets/admin_design/css/style.css');?>" >
                <link rel="stylesheet" href="<?=base_url('assets/admin_design/css/style1.css');?>" >

		<!-- <link href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
                <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> --> 
	  <!-- Ionicons -->

  		 <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">-->

  		 <link href="<?=base_url('assets/admin_design/css/RegalCalendar.css');?>" rel="stylesheet" type="text/css" />


	  
	</head>
<body >
