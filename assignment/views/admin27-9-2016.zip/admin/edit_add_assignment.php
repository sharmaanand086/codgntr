<?php include( 'header.php');?>
<?php include( 'top_menubar.php');?>
      <style>
           .error{
                   color: red;
                 }
       </style>
 <?php  //echo $iid;
?>
<?php //var_dump($assdetails);
?>
<?php foreach($assdetails as $row){?>
<section class="dash_wrapp">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="wrapper">
                      
                       <?php 
                       $attributes = array("id" => "uploadassigmentform", "name" => "uploadassigmentform");
                       echo form_open_multipart("newadmin/uuploadassignment/$iid", $attributes);
                      ?>
                                
                        <div class="dash_head ">
                            <h1>New Assignment</h1>
                            <a href="<?php echo base_url('newadmin/dashboard');?>">Cancel</a>
                        </div>
                       
                        <input class="form-control ass_input" type="text" name="assignmentname" id="assignmentname" placeholder="<?=$row->name?>" value="">
                         <span class="error">
                         <?php echo form_error('assignmentname'); ?>
                         </span>
                           

               <textarea class="form-control" name="description" id="description" cols="20" rows="4" placeholder="<?=$row->discription?>"></textarea>
               <span class="error"><?php echo form_error('description'); ?></span>

                            <div class="section_procedure">
                                <ul class="ass_procedure">
                                    <li >
                                    <div class="btn_add_wrapp">
                                        <a  id="click_ref" onclick="div_show()" class="add_file_btn add_file_inline">Add Reference File</a>
                                    </div>


                                    <!-- modal box open -->
                                   
                                        <div id="open_file" class="inner" style="display:none;">
                                            <div class="text-box">
                                                <!--<a href="">
                                      <img src="<?php echo base_url('assets/admin_design/images/dashboard/Drag_Drop_icon.png');?>" alt="">
                                                </a>-->
                                           
                                           
                                               <input class="choose_file" type="file" name="fileassignment" id="fileassignment" placeholder=" " value="" style="width: 400px; height: 400px; margin:auto;border: 3px dashed #696969; background: url('http://smbseminar.com/assignment/assets/images/latest/Untitled-2.png'); background-repeat: no-repeat; background-position: center; cursor: pointer;">
                                                <!--<h1>Drag & Drop</h1>-->
                                                <!--<p>your assignment file here, <span style="color:#a6a6a6">or <a href="">browse</a></span>
                                                </p>-->
                                                <div class="cancel-file">
                                                    <a onclick ="div_hide()" class="js-modal-close">Cancel</a>
                                                </div>
                                            </div>
                                        </div>
                                       
                                            <!-- modal box open -->

                                            <!--<p>No reference file added</p>-->
                                              
                                </li>


                                        <input type="text" name="datesubtext" value=""  style="display: none;"  id="abcdef">
                                        <input type="date" name="datesub" value=""  style="display: none;"  id="abcdefg">
                                   <!-- <input type="text" name="datesub" value=""  style="display: none;"  id="abcdef">-->
                                   <!--<span class="error"><?php //echo form_error('datesub'); ?></span>-->
                                    <!-- calender design -->
                                    <script type="text/javascript">
                                        $(document).ready(function() {
                                            $('#rCalendar').RegalCalendar({
                                                theme: 'cyan',
                                                base: 'white',
                                                modal: false,
                                                minDate: new Date(2016, 1 - 1, 1),
                                                maxDate: new Date(2016, 12 - 1, 31),
                                                tooltip: 'bootstrap',
                                                inputDate: '#inputDate',
                                                inputEvent: '#inputEvent',
                                                inputLocation: '#inputLocation',
                                                mapLink: 'map',
                                                twitter: ' ',
                                                twitter1: ' ',
                                                twitter2: ' ',
                                                twitter3: ' ',
                                                twitter4: ' '
                                            });
                                        });
                                    </script>
                                    <div class=" overlay-content popup1">
                                        <div class="calender_modal">
                                            <div style=" display: inline-block;background: #fff; border-radius:8px; padding: 44px; box-shadow: 0px 0px 30px 0 #e6e6e6;">
                                                <div id="rCalendar" class="regalcalendar" style="">

                                                </div>
                                            </div>
                                        </div>
                                    </div>



                                    <!-- calender design -->
                                    <li class="wrapp_date_box">
                                        <div class="btn_date_wrapp">
                                            <a href="" class="date_btn date_btn_inline show-popup" data-showpopup="1">Set A Due Date</a>
                                        </div>
                                        <!-- <p>No due date set</p>-->
                                        
                                        <div class="date_picker">	
	                                        <p id="date7">No due date set</p>
	                                        <p id="date5" style="display: none;">No due date set</p>
	                                        <p id="date6" style="display: none;">No due date set</p>
                                        </div>	
                                    </li>


                                    <li class="wrapp_btn">
                                        <div class="btn_send_wrapp">
                                        <!-- <a  class="send_file_btn send_file_inline">Finish & Send Assignment</a>-->
	   <input type="submit" class="date_btn date_btn_inline top_sild "  data-lead-id="banner-btn" value="Finish & Send Assignment" id="submit" name = "addassignment">
              <!--<button type="submit" id="submit" name ="addassignment" class="send_file_btn send_file_inline" >Finish & Send Assignment</button>-->
                                        </div>
                                    </li>

                                </ul>
                                </div>
                       <?php //echo form_close(); ?>
                    </div>
                </div>

            </div>
        </div>
</section>
<?php } ?>
<div class="overlay-bg">
</div>

<script>
        //Function To Display Popup
         function div_show() {
            document.getElementById('open_file').style.display = "block";
          }
        //Function to Hide Popup
         function div_hide(){
             document.getElementById('open_file').style.display = "none";
          }
          

  //function for change
 $('#fileassignment').change(function() {
           
                          
             $('#open_file').css( {
                            "display":"none"});
              //alert('heyyy');
          });
       
</script>




<script>
    $(document).ready(function() {
          
        // function to show our popups
        function showPopup(whichpopup) {
            var docHeight = $(document).height(); //grab the height of the page
            var scrollTop = $(window).scrollTop(); //grab the px value from the top of the page to where you're scrolling
            $('.overlay-bg').show().css({
                'height': docHeight
            }); //display your popup background and set height to the page height
            $('.popup' + whichpopup).show().css({
                'top': scrollTop + 35 + 'px'
            }); //show the appropriate popup and set the content 20px from the window top
        }

        // function to close our popups
        function closePopup() {
            $('.overlay-bg, .overlay-content').hide(); //hide the overlay
        }

        // timer if we want to show a popup after a few seconds.
        //get rid of this if you don't want a popup to show up automatically
        //setTimeout(function() {
        // Show popup3 after 2 seconds
        //showPopup(3);
        // }, 2000);


        // show popup when you click on the link
        $('.show-popup').click(function(event) {
            event.preventDefault(); // disable normal link function so that it doesn't refresh the page
            var selectedPopup = $(this).data('showpopup'); //get the corresponding popup to show

            showPopup(selectedPopup); //we'll pass in the popup number to our showPopup() function to show which popup we want
        });

        // hide popup when user clicks on close button or if user clicks anywhere outside the container
        $('.close-btn, .overlay-bg').click(function() {
            closePopup();
        });

        // hide the popup when user presses the esc key
        $(document).keyup(function(e) {
            if (e.keyCode == 27) { // if user presses esc key
                closePopup();
            }
        });
        
       
    });

 
                
 
</script>




<!-- calender design -->

<?php include( 'footer.php');?>