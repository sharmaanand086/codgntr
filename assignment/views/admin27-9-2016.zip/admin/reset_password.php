<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<title> Speak To A Fortune </title>
		
		<!-- Bootstrap Core CSS -->

		<link href="<?=  base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
		<link href="<?=  base_url('assets/css/bootstrap.css');?>" rel="stylesheet"> 
		<!-- Custom Fonts -->
		<link href="<?=  base_url('assets/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">
		<!-- Custom CSS -->
		<link rel="stylesheet" href="<?=  base_url('assets/css/style.css');?>" >
		<!-- <link href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet" /> --> 
	
	</head>
	  
        <style>
           .error{
                   color: red;
                 }
       </style>
<body class="speaktofortune">
         <?php $ccid=$userid;?>
	<div class="materialContainer">
       <div class="row" style="margin: 0px;">
           <div class="wrapper-content">
	          <div class="box">

	         <div class="logintitle">
                         
                             <img src="<?=  base_url('assets/images/login/logo.png');?>" alt="">
	         	
	         </div>
	          
                 <?php 
                       $attributes = array("id" => "updatepassform", "name" => "updatepassform");
                       echo form_open("newadmin/updatepass/$ccid", $attributes);
                       
                ?>
                
	        <div class="input">
	           <label for="newpassword">New Password</label>
                    <!-- <input type="email" name="email">-->
                       
	             <input type="text" name="newpassword" id="newpassword">
	              <span class ="error"><?php echo form_error('newpassword'); ?></span>
                    <span class="spin"></span>
     	       </div>
               
	       <div class="input">
	            <label for="confirmpassword">Confirm New Password</label>
	            
	            <input type="text" name="confirmpassword" id="confirmpassword">
	            <span class ="error"><?php echo form_error('confirmpassword'); ?></span>	
                    <span class="spin"></span>
      	       </div>

      	    <div class="btn-inline-wrap">
                <input type="submit" class="btn3 btn-inline1"  data-lead-id="banner-btn" value="Change Password" id="submit" name = "Change Password">
               <!-- <a href="loading_assignment.php"  class="btn btn-inline" data-lead-id="banner-btn"> Go Inside </a>-->
            </div>

			
			<center>
	                        <?php echo form_close(); ?>
                                <span class = "error"> <?php echo $this->session->flashdata('resetpassmsg');?></span>
                        </center>

	     </div>
        </div>  
      </div>
	</div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script>
      $.fn.center = function () {
        this.css("position","absolute");
        this.css("top", Math.max(0, (($(window).height() - $(this).outerHeight()) / 2) + $(window).scrollTop()) + "px");
        this.css("left", Math.max(0, (($(window).width() - $(this).outerWidth()) / 2) + $(window).scrollLeft()) + "px");
        return this;
      }

      $("#banner-btn").on("click", function(){
       window.location="href";
       // window.demo1.index3.
      });
    </script>
<!-- jQuery -->
		<script src="<?=  base_url('assets/js/jquery.js');?>"></script>
		<!-- Bootstrap Core JavaScript -->
		<script src="<?=  base_url('assets/js/bootstrap.min.js');?>"></script>

	    <script src="<?=  base_url('assets/js/script.js');?>"></script>
	    
       <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="<?=  base_url('assets/js/index.js');?>"></script>

</body>
</html>