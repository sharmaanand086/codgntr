<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<title> Speak To A Fortune </title>
		
		<!-- Bootstrap Core CSS -->
		<link href="<?=base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
		<link href="<?=base_url('assets/css/bootstrap.css');?>" rel="stylesheet"> 
		<!-- Custom Fonts -->
		<link href="<?=base_url('assets/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">
		<!-- Custom CSS -->
		<link rel="stylesheet" href="<?=base_url('assets/css/style.css');?>" >
		<!-- <link href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet" /> --> 
	
	</head>
<body class="speaktofortune">

	<div class="materialContainer4">
	    <div class="box7">

	         <div class="logintitle">
	         	<img src="<?=base_url('assets/images/login/logo.png');?>" alt="">
	         </div>
			<div class="animated_class">
				<canvas class="cancv" height="160"></canvas>
			</div>
	        <div class="fst_line2">
	        	<p class="reset-link">123A password reset link has been mailed to you.</p>
	        	<p>Please click on that link to reset your password.</p>
	        </div>
	        
			<div class="forgotpass">
				 <a href="<?=base_url();?>newadmin/login" class="pass-forgot2">Log In</a>
			</div>
			
	    </div>


	</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
 
		<script src="<?=base_url(assets/js/jquery.js);?>"></script>
		<!-- Bootstrap Core JavaScript -->
		<script src="js/bootstrap.min.js"></script>

	    <script src="js/script.js"></script>
	    
		 <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="js/index.js"></script>
        <script type="text/javascript">
   var start = 100;
var mid = 145;
var end = 220;
var width = 18;
var leftX = start;
var leftY = start;
var rightX = mid + 2;
var rightY = mid - 3;
var animationSpeed = 20;

var ctx = document.getElementsByTagName('canvas')[0].getContext('2d');
ctx.lineWidth = width;
ctx.strokeStyle = 'rgba(165, 189, 82, 1)';

for (i = start; i < mid; i++) {
    var drawLeft = window.setTimeout(function () {
        ctx.beginPath();
        ctx.moveTo(start, start);
        ctx.lineTo(leftX, leftY);
        ctx.lineCap = 'round';
        ctx.stroke();
        leftX++;
        leftY++;
    }, 1 + (i * animationSpeed) / 3);
}

for (i = mid; i < end; i++) {
    var drawRight = window.setTimeout(function () {
        ctx.beginPath();
        ctx.moveTo(leftX + 2, leftY - 3);
        ctx.lineTo(rightX, rightY);
        ctx.stroke();
        rightX++;
        rightY--;
    }, 1 + (i * animationSpeed) / 3);
}
</script>


</body>
</html>