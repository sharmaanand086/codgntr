<?php include( 'header.php');?>
<!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php echo base_url()?>newadmin/dashboard"><img src="<?=base_url('assets/admin_design/images/dashboard/logo.png')?>" class="img-responsive" alt="company logo" /></a>
        </div>
        <div class="collapse navbar-collapse " id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav  custom-menu" id="navbar">
            <li>
              <a href="<?php echo base_url('newadmin/dashboard');?>" class="strong_active"><span class="l1"> Dashboard </span><span class="l2"> Dashboard </span>
                <!-- <span class="label">1</span> -->
               <!--  <span id="rJobCntr" class="rJobCntr" style="display: inline;">1</span> -->
              </a>
            </li>
            <li>
              <a href="<?php echo base_url('newadmin/participants');?>" class="strong_active1"><span class="l1"> Participants </span><span class="l2"> Participants </span> 
              </a>
            </li>
            <li>
              <a href="<?php echo base_url('newadmin/logout');?>"><span class="l1"> Logout </span><span class="l2"> Logout </span> 
              </a>
            </li>                     
          </ul>
          
            <div id="" class="wrapp_ass pull-right">
              <a href="<?php echo base_url('newadmin/addassignemnt');?>" class="add_assi">+ Add assignment</a>
            </div>                  
       
        </div>
      </div>
    </nav>
<?php include( 'footer.php');?>