<?php include( 'header.php');?>
<?php include( 'top_menubar.php');?>


<section class="assing_module">
    <div class="container">
        <div class="row">
            <div class="wrap">
                <form action="" autocomplete="on">
                    <div class="input_form">
                        <input type="text" class="serach_input form-control" id="search_text" placeholder="Search assignment, people">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php //var_dump($totalnoassignment); 
?>
<?php 
     //var_dump($assignment);
?>
<?php 
     // var_dump($view);
?>
<?php
        // var_dump($userstatus); 
?>
<section class="participants">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-12 wrap_parti" id="result">
                <ul>
                     <?php  //$i=0;
                     ?>
                   <?php foreach($user as $row){  ?>
                                   <?php  $completetotal=0;?>
                  
                    <li class="parti_row">
                        <div class="chunk-details">
                       
                            <div class="col-md-12 parti_info" id="<?=$row->contactid?>">
                                <div class="col-md-6 parti_name ">
                                      <?php  $currecheckid=$row->contactid;?>
                                    <p><?=$row->name?></p><p><?php echo "(";?><?=$row->contactid?><?php echo ")"; ?></p>
                                </div>
                                <div class="col-md-3 details_comp">
                                      <?php 
                                      foreach($userstatus as $checkuserrow){ 
                                                                              $checkckeid=$checkuserrow->contact_id;
                                                                               if($checkckeid== $currecheckid){
                                                                               
                                                                                     $completetotal=$completetotal+1;
                                                                               }
                                                                           }
                                      ?>
                                    <span class="no_ass"><?=$completetotal?></span><span class="">/</span><span class=""><?=$totalnoassignment?> Assignments</span><span class="no_ass">Complete</span>
                                </div>
                                <div class="col-md-2 view_details">
                                    <p>View Details</p>
                                </div>
                                <div class="col-md-1 batch_count">
                                      
                                    <img src="<?=base_url('assets/admin_design/images/dashboard/sheld.png');?>" alt="">
                                    <p><?=intval($completetotal/3)?></p>
                                </div>
                            </div>
                            <!-- hide tabel -->
                            <div class="col-md-12 details_view" id="<?="a$row->contactid"?>">
                                 <?php $currentuserid=$row->contactid ?>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th colspan="4" class="name_parti"><?=$row->name?></th>
                                        </tr>
                                    </thead>
                                    <tbody class="">
                                      <?php   foreach($assignment as $assignmentrow){
                                            $flag=0; ?>
                                        <tr>
                                            <td class="query_no"><?=$assignmentrow->aid?>.</td>
                                            <td class="query_write"><?=$assignmentrow->name?></td>
                                            <?php $currentassignemnt=$assignmentrow->aid; ?>
                                            <?php foreach($userstatus as $assignmentrow){
                                                     $cccurentassig=$assignmentrow->assignment_no;
                                                     $cccuruser=$assignmentrow->contact_id;
                                                     $cccurstatus=$assignmentrow->status;
                                                     $cccurstatoverdue=$assignmentrow->overdue;
                                            ?>
                                                   <?php  if(($cccuruser==$currentuserid)&&($cccurentassig==$currentassignemnt) ){
                                                                // echo  $cccuruser;echo $cccurentassig;
                                                                    if($cccurstatus==1){  ?>
                                                                              <?php if($cccurstatoverdue==0){ ?>    
                                                                               <td class="on-time">Completed on time </td>
                                                                                <?php foreach($view as $viewrow){ 
                                                                                       $ccviewid=$viewrow->contactid;
                                                                                       $ccviewass=$viewrow->aid;
                                                                                       $ccviewfile=$viewrow->file;
                                                                                 ?>
                                                                                 <?php if(($cccuruser==$ccviewid)&&($cccurentassig==$ccviewass)){ ?>
                                                                                 
                          <td class="view-assi"><a  href="<?php echo base_url();?>uploads/2_submission/<?php echo $ccviewfile;?>" target="_blank" style="color:black;text-decoration: none;">View assignment</a></td>
                                                                                  <?php } ?>      
                                                                                 <?php } ?>
                                                                               <?php }else{  ?>
                                                                                <td class="on-time"><span style="color:red;">Completed late</span></td>
                                                                                 <?php foreach($view as $viewrow){ 
                                                                                       $ccviewid=$viewrow->contactid;
                                                                                       $ccviewass=$viewrow->aid;
                                                                                       $ccviewfile=$viewrow->file;
                                                                                 ?>
                                                                                 <?php if(($cccuruser==$ccviewid)&&($cccurentassig==$ccviewass)){ ?>
                                                                                       
                           <td class="view-assi"><a  href="<?php echo base_url();?>uploads/2_submission/<?php echo $ccviewfile;?>" target="_blank" style="color:black;text-decoration: none;">View assignment</a></td>
                                                                                  <?php } ?>      
                                                                                 <?php } ?>
                                                                                <!--<td class="view-assi">View assignment</td>-->
                                                                           
                                                                                 
                                                                             <?php   }?> 
                                                             <?php       $flag=$flag+1; }
                                                                 
                                                              } ?>
                                              <?php }?>
                                               <?php if($flag==0){ ?>
                                               <td class="on-time">pending</td>
                                               <td class="view-assi">View assignment</td>
                                               <?php } ?>
                                        </tr>
                                         <?php     }  ?>
                                    </tbody>
                                </table>
                            </div>
                          

                        </div>
                    </li>
                     
                   <?php } ?>   
                          


                </ul>
            </div>
        </div>
    </div>
</section>
<?php include( 'footer.php');?>
<script>

      $(document).ready(function() {
          $(".strong_active1").addClass('active');
          //$(".trd").addClass('active');

      });

     $(document).ready(function(){

         
         $(".parti_info").click(function(){
                var ac=$(this).attr('id');
                  var acd="#a"+ac;
                  console.log(acd);
            
               //alert('heyyy its calll');

              $(acd).slideToggle(500);

              $(acd).toggleClass("chunk_data");
          
              });


         $(".parti_info1").click(function(){
                
                  var ac=$(this).attr('id');
                  var acd="#a"+ac;
                  console.log(acd);

              $(acd).slideToggle(500);

              $(acd).toggleClass("chunk_data");
          
              });

         });

    //$(document).ready(function(){
           // $('.parti_info').click(function () {

            //$('.details_view').hide();      // hide previous
            //$(this).next().show('slow'); // show next element in dom (it will be <div> with class 'foo')

          //  $('.details_view').slideUp("slow"); 
            
          //  $(this).next().slideDown('slow');

        //});
    // });
</script>
<script>  
 /* $(document).ready(function(){  
     $('#search_text').keyup(function(){  
           var txt = $(this).val();  
           if(txt != '')  
           {  
                $.ajax({  
                     url:"<?php echo site_url('newadmin/search_name'); ?>",  
                     method:"post",  
                     data:{search:txt},  
                     dataType:"text",  
                     success:function(data)  
                     {  
                          $('#result').html(data);  
                     }  
                });  
           }  
           else  
           {  
                      $('#result').html('display this'); 
                        
           }  
      });  
 });  */
 </script>  
<script>  

      $('#search_text').keyup(function(){  
           var valThis = $(this).val().toLowerCase();  
            if(valThis == ""){
        $('ul > .parti_row').show();
    } else {
        $('ul > .parti_row').each(function(){
            var text = $(this).text().toLowerCase();
            (text.indexOf(valThis) >= 0) ? $(this).show() : $(this).hide();
        });
   };
  });
 </script>  