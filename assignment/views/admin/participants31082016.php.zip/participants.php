<?php include( 'header.php');?>
<?php include( 'top_menubar.php');?>


<section class="assing_module">
    <div class="container">
        <div class="row">
            <div class="wrap">
                <form action="" autocomplete="on">
                    <div class="input_form">
                        <input type="text" class="serach_input form-control" id="search_text" placeholder="Search assignment, people">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php //var_dump($user); ?>

<section class="participants">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-12 wrap_parti" id="result">
                <ul>
                     <?php $i=0;?>
                   <?php foreach($user as $row){  ?>
                       <?php if($i==0){ ?>
                    <li class="parti_row">
                        <div class="chunk-details">
                            <div class="col-md-12 parti_info" id="<?=$row->contactid?>">
                                <div class="col-md-6 parti_name ">
                              
                                    <p><?=$row->name?></p><p><?php echo "(";?><?=$row->contactid?><?php echo ")"; ?></p>
                                </div>
                                <div class="col-md-3 details_comp">
                                    <span class="no_ass">7</span><span class="">/</span><span class="">26 Assignments</span><span class="no_ass">Complete</span>
                                </div>
                                <div class="col-md-2 view_details">
                                    <p>View Details</p>
                                </div>
                                <div class="col-md-1 batch_count">
                                      
                                    <img src="<?=base_url('assets/admin_design/images/dashboard/sheld.png');?>" alt="">
                                    <p>3</p>
                                </div>
                            </div>
                            <!-- hide tabel -->
                            <div class="col-md-12 details_view" id="<?="a$row->contactid"?>">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th colspan="4" class="name_parti"><?=$row->name?></th>
                                        </tr>
                                    </thead>
                                    <tbody class="">
                                        <tr>
                                            <td class="query_no">1.</td>
                                            <td class="query_write">Write your ETR</td>
                                            <td class="on-time">Completed on time</td>
                                            <td class="view-assi">View assignment</td>
                                        </tr>
                                        <tr>
                                            <td class="query_no">2.</td>
                                            <td class="query_write">Seminar Module</td>
                                            <td class="on-time"><span style="color:red;">Completed 3 days late</span></td>
                                            <td class="view-assi">View assignment</td>
                                        </tr>
                                        <tr>
                                            <td class="query_no">3.</td>
                                            <td class="query_write">Audiance Engagement</td>
                                            <td class="on-time"><span style="color:#a6a6a6;">Pending</span></td>
                                            <td class="view-assi"><span style="color:#a6a6a6;">View assignment</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </li>
                      <?php $i++; ?>
                     <?php }else{ ?>
                          <li class="parti_row">
                        <div class="chunk-details">
                            <div class="col-md-12 parti_info1" id="<?=$row->contactid?>">
                                <div class="col-md-6 parti_name ">
                              
                                    <p><?=$row->name?></p><p><?php echo "(";?><?=$row->contactid?><?php echo ")"; ?></p>
                                </div>
                                <div class="col-md-3 details_comp">
                                    <span class="no_ass">7</span><span class="">/</span><span class="">26 Assignments</span><span class="no_ass">Complete</span>
                                </div>
                                <div class="col-md-2 view_details">
                                    <p>View Details</p>
                                </div>
                                <div class="col-md-1 batch_count">
                                      
                                    <img src="<?=base_url('assets/admin_design/images/dashboard/sheld.png');?>" alt="">
                                    <p>3</p>
                                </div>
                            </div>
                            <!-- hide tabel -->
                            <div class="col-md-12 details_view1" id="<?="a$row->contactid" ?>">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th colspan="4" class="name_parti"><?=$row->name?></th>
                                        </tr>
                                    </thead>
                                    <tbody class="">
                                        <tr>
                                            <td class="query_no">1.</td>
                                            <td class="query_write">Write your ETR</td>
                                            <td class="on-time">Completed on time</td>
                                            <td class="view-assi">View assignment</td>
                                        </tr>
                                        <tr>
                                            <td class="query_no">2.</td>
                                            <td class="query_write">Seminar Module</td>
                                            <td class="on-time"><span style="color:red;">Completed 3 days late</span></td>
                                            <td class="view-assi">View assignment</td>
                                        </tr>
                                        <tr>
                                            <td class="query_no">3.</td>
                                            <td class="query_write">Audiance Engagement</td>
                                            <td class="on-time"><span style="color:#a6a6a6;">Pending</span></td>
                                            <td class="view-assi"><span style="color:#a6a6a6;">View assignment</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </li>
                           <?php $i--; ?>
                       <?php }?>
                   <?php  }  ?>


                </ul>
            </div>
        </div>
    </div>
</section>
<?php include( 'footer.php');?>
<script>

      $(document).ready(function() {
          $(".strong_active1").addClass('active');
          //$(".trd").addClass('active');

      });

     $(document).ready(function(){

         
         $(".parti_info").click(function(){
                var ac=$(this).attr('id');
                  var acd="#a"+ac;
                  console.log(acd);
            
               //alert('heyyy its calll');

              $(acd).slideToggle(500);

              $(acd).toggleClass("chunk_data");
          
              });


         $(".parti_info1").click(function(){
                
                  var ac=$(this).attr('id');
                  var acd="#a"+ac;
                  console.log(acd);

              $(acd).slideToggle(500);

              $(acd).toggleClass("chunk_data");
          
              });

         });

    //$(document).ready(function(){
           // $('.parti_info').click(function () {

            //$('.details_view').hide();      // hide previous
            //$(this).next().show('slow'); // show next element in dom (it will be <div> with class 'foo')

          //  $('.details_view').slideUp("slow"); 
            
          //  $(this).next().slideDown('slow');

        //});
    // });
</script>
<script>  
 /* $(document).ready(function(){  
     $('#search_text').keyup(function(){  
           var txt = $(this).val();  
           if(txt != '')  
           {  
                $.ajax({  
                     url:"<?php echo site_url('newadmin/search_name'); ?>",  
                     method:"post",  
                     data:{search:txt},  
                     dataType:"text",  
                     success:function(data)  
                     {  
                          $('#result').html(data);  
                     }  
                });  
           }  
           else  
           {  
                      $('#result').html('display this'); 
                        
           }  
      });  
 });  */
 </script>  
<script>  

      $('#search_text').keyup(function(){  
           var valThis = $(this).val().toLowerCase();  
            if(valThis == ""){
        $('ul > .parti_row').show();
    } else {
        $('ul > .parti_row').each(function(){
            var text = $(this).text().toLowerCase();
            (text.indexOf(valThis) >= 0) ? $(this).show() : $(this).hide();
        });
   };
  });
 </script>  