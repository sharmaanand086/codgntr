<?php include( 'header.php');?>
<?php include( 'top_menubar.php');?>
<script type="text/javascript" src="<?=base_url('assets/js/jquery.slimscroll1.js');?>"> </script>
<script type="text/javascript" src="<?=base_url('assets/js/jquery.slimscroll.js');?>"> </script>
<!-- 
<section class="folder_ass">
    <div class="container">
        <div class="row">
            <img class="img-responsive folder" src="<?=base_url('assets/images/dashboard/cancel.png');?>" alt="">
            <img class="img-responsive arrow" src="<?=base_url('assets/images/dashboard/Arrow.png');?>"  alt=""  style="width:390px;height:280px;">
        </div>
    </div>
</section> -->



<section class="assing_module">
    <div class="container">
        <div class="row">
            <div class="wrap">
                <form action="" autocomplete="on">
                    <div class="input">
                        <label for="search">Search assignment,people</label>

                        <input id="search" name="search" type="text">
                        <span class="spin"></span>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php var_dump($view); 
?>
<?php  //var_dump($assignment);
  // echo "<br>";
?>

<?php  //var_dump($user);
  // echo "<br>";
?>

<?php // var_dump($userstatus);
   //echo "<br>";
?>
<ul>
<?php 
      
foreach($name as $row1){
           $nameuser=$row1->name;
 }
 //echo  $nameuser;
?>

<?php foreach($assignment as $row ){ ?>
  <?php          $update=$row->udate;
                 $sudate=$row->subdate;
           
              $date = date_create($update);
              $date1= date_create($sudate);
        
             
             //var_dump($assignmentno);
              $currentassignment=$row->aid;
        ?>
 <li class="comments12">      
<section class="assi_section" id="assi_section<?php echo $row->aid;?>">

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 seminar_modal">
                <div class="col-xs-12 assi-wrapp ">
                    <div class="assi_pull-left">
                        <img class="img-responsive" src="<?=base_url('assets/admin_design/images/dashboard/Assignment_Icon.png');?>">
                    </div>
                    <div class="assi-body">
                        <div class="assi-heading">
                             <h1><?php echo $row->aid; ?>.<?php echo $row->name; ?></h1>
                            <p><?php echo date_format( $date , 'jS F, Y');?></p>
                        </div>
                        </div>
                        <div class="ass-objective">
                            <p><?php echo $row->discription;?></p>
                        </div>
                        <div class="btn-inline-wrap-letest_ass">
                            <a href="" class="view_btn btn_view-inline" alt=""> Edit </a>
                        </div>
                        <div class="ass_complete">
                             <img src="<?=base_url('assets/admin_design/images/dashboard/timmer.png');?>" alt="">
                             <p>Complete before:<?php echo date_format( $date1 , 'jS F, Y');?></p>
                        </div>
                    </div>
                </div>
            </div>
        
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                <div class=" user-comments " id="<?php echo "$row->aid"; ?>" value="<?php echo "$row->aid"; ?>">
                    <div class="notification">
                    <div class="wap_hide" id="<?php echo "b$row->aid"; ?>">
                        <img src="<?=base_url('assets/admin_design/images/dashboard/New Comment.png');?>" alt="">
                        <p>3</p> 
                    </div>
                        <h1 class="ass-det both_show" id="<?php echo "c$row->aid"; ?>">Assignment Details</h1>

                    </div>
                    <div class="commnt_count">
                    <div class="wap_hide" id="<?php echo "d$row->aid"; ?>">
                        <img src="<?=base_url('assets/admin_design/images/dashboard/Tick.png');?>" alt="">
                        <span class="comm_no">7</span>/<span class="comm_total">26</span>
                    </div>
                        <h1 class="cmmnt both_show" id="<?php echo "e$row->aid"; ?>">Comments</h1>

                    </div>
                </div>
            </div>
        </div>

 


        <!-- assgnment tabel start-->

       

        <div class="ass_wrapper" id="<?php echo "a$row->aid"; ?>">
            <!--<div class="div_wrapper" id="testDiv">-->
             <div class="div_wrapper">
                <ul class="main_wrapper">
            
                   <?php foreach($user as $user1){ ?>
                                <?php $currentusert=$user1->contactid; ?>
                                 <?php $cccheckcounter=0; ?>
                                 <li class="ass_list">
                        <div class="name">
                      
                                <p><?=$user1->name?></p>
                               <!-- <p><?=$user1->contactid?></p>-->
                        </div>
                        <div class="time all_width">
                                 <?php foreach($userstatus as $rowstatus){ 
                                        
                                        $currentstatuserid=$rowstatus->contact_id;
                                        $currentstatassid=$rowstatus->assignment_no;
                                        $currentstatus=$rowstatus->status;
                                      if(($currentusert==$currentstatuserid)&&($currentstatassid== $currentassignment)){ ?>
                                      
                                                
                                            <?php       if($currentstatus==1){ $cccheckcounter=$cccheckcounter+1; ?>
                                                  
                                                      <p>ontime</p>
                                                     
                                       <?php             } 
                                     }
                                       
                                          
                                 } ?>
                                  <?php if($cccheckcounter==0){ ?>
                                  <p>pending</p>
                                  <?php }else{ $currentstatassid=0;} ?>
                            
                        </div>
                        <div class="status all_width">
                            <p>View</p>
                           <!-- <p>currentassignment:<?=$currentassignment?></p>-->
                           
                            
                        </div>
                        <div class="batch all_width">
                            <img src="<?=base_url('assets/admin_design/images/dashboard/sheld.png');?>" alt="">
                            <p>3</p>
                        </div>
                    </li>
               
                    
                    <?php } ?>
                     <p>currentassignment:<?=$currentassignment?></p>
                </ul>
            </div>
            <!-- assgnment tabel end-->


            <!--  comments part start-->
            <div class="div_wrapper1">
                <div class="commt_wrapp" id="panel">
                    <div class="comment-here">
                         <form name="form1">
                            <div class="input-area">
                            Enter Your ChatName :<input type="text" id="uname" name="uname" value="<?php echo  $nameuser; ?>"  disabled /><br>
                                
                                <input type="text" class="addinput_controls search" name ="<?php echo $row->aid;?>" id="msg<?php echo $row->aid;?>" placeholder="Type your comment here. Press enter to  post">
                                       <!--<input type="text" class="addinput_controls search" name ="msg" id="msg" placeholder="Type your comment here. Press enter to  post">-->
                                        <!-- <a href="#" onclick="submitChat()">send</a> -->
                                 <span class="glyphicon glyphicon-paperclip "></span>
                            </div>
                        </form>
                    </div>
                    <div class="chat_process" id="chat_process<?php echo $row->aid;?>">
                    </div>
                </div>
            </div>

            <!--  comments part end-->

        </div>


    </div>
</div>

</section>
</li>
<?php }?>

</ul>
<script>  

      $('#search').keyup(function(){  
          //alert('heyy');
           var valThis = $(this).val().toLowerCase();  
            if(valThis == ""){
        $('ul > .comments12').show();
    } else {
        $('ul > .comments12').each(function(){
            var text = $(this).text().toLowerCase();
            (text.indexOf(valThis) >= 0) ? $(this).show() : $(this).hide();
        });
   };
  });
 </script>  
<script>
   
     
    $(function() {

        $(".input input").focus(function() {

            $(this).parent(".input").each(function() {
                $("label", this).css({
                    "line-height": "18px",
                    "font-size": "15px",
                    "font-weight": "100",
                    "top": "2px"
                })
                $(".spin", this).css({
                    "width": "100%"
                })
                $(".input input").css({
                    "color": "#000",
                    "font-weight": "600",
                    //"height": "50px",
                    "top": "5px"
                })
            });
        }).blur(function() {
            $(".spin").css({
                "width": "0px"
            })
            if ($(this).val() == "") {
                $(this).parent(".input").each(function() {
                    $("label", this).css({
                        "line-height": "60px",
                        "font-size": "20px",
                        "font-weight": "300",
                        "top": "0px"
                    })
                });

            }
        });
    });

</script>
<script type="text/javascript">
    $(document).ready(function(){
               var ttchange=0;
    $(".user-comments").click(function(){
       //$(".ass_wrapper").slideToggle(500);
             

       // $(".wap_hide").toggleClass("not_show").delay(500);

        //$(".user-comments").toggleClass("border-radius_set",500);
       // $(".both_show").toggleClass("_show");
                
         ttchange=ttchange+1;
           // alert(ttchange);
            
                 
         var a = $(this).attr('id');
         var hideshow='#assi_section'+a;
             if(ttchange==1){
                                //alert('this is for first');
                                $(".assi_section").hide();
                                $(hideshow).show();
                              
                            }
              if(ttchange==2){
                              // alert('this is second');
                               $(".assi_section").show();
                               ttchange=0;
                             }
            
             //var abc1234=$(this).attr('value');
             //alert(abc1234);
             var ts='#'+a;
            // alert(ts);
            
             var abc2='a'+a;
             var th='#'+abc2;
             //alert(th);

             var abc3='b'+a;
             var th1='#'+abc3;
            // alert(th1);

             var abc4='c'+a;
             var th2='#'+abc4;
             //alert(th2);

             var abc5='d'+a;
             var th3='#'+abc5;
            // alert(th3);
 
             var abc6='e'+a;
             var th4='#'+abc6;
             //alert(th4);
             
             //var abc7='j'+abc1;
             //var th5='#'+abc7;
             //alert(th5);

             
             $(th).slideToggle(500);


             $(th1).toggleClass("not_show").delay(500);
             $(th3).toggleClass("not_show").delay(500);

             $(ts).toggleClass("border-radius_set",500);
             $(th2).toggleClass("_show");
             $(th4).toggleClass("_show");

         setInterval(function(){ 
           getSuccessmessage(a);
        }, 1000);

   });
   });


<!-- /******************************comment start ***************************************/ -->
    </script>
<script type="text/javascript">
    $(document).ready(function() {
    $(".strong_active").addClass('active');
    //$(".ssd").addClass('active');

});
</script>
    <script type="text/javascript">

$(".addinput_controls").on("keydown",function search(e) {

    if(e.keyCode == 13) {
         var id1 = $(this).attr('name');
          //alert(id1);
         getSuccessOutput(id1);
         
   // submitChat();
     document.getElementById('msg'+id1).value = "";

    }

});

function getSuccessOutput(id1) {
          // alert(id1);
    $.ajax({
           "url": "<?php echo site_url('newadmin/chat')?>",
           "type": "POST",
           data: {msg: $("#msg"+id1).val(),name: $("#uname").val(),id:id1},
           dataType: "text",  
            cache:false,
         complete: function (response) {
           // $('#output').html(response.responseText);
           // alert('this is complete !!');
        },
        success :  function (result) {
           // $('#output').html('Bummer: there was an error!');
               //$('#chat_process').html(result);
              getSuccessmessage();
          // alert('success in called !!');
        },

        error: function () {
           // $('#output').html('Bummer: there was an error!');
          // alert('errore !!');
        },
    });
    return false;
}
function getSuccessmessage(id1) {
    $.ajax({
           "url": "<?php echo site_url('newadmin/chat_message')?>",
           "type": "POST",
           data: {msg: $("#msg").val(),name: $("#uname").val(),id:id1},
           dataType: "text",  
            cache:false,
         complete: function (response) {
           // $('#output').html(response.responseText);
           // alert('this is complete111 !!');
        },
        success :  function (result) {
           // $('#output').html('Bummer: there was an error!');
               $('#chat_process'+id1).html(result);
          // alert('success in called11111 !!');
        },

        error: function () {
           // $('#output').html('Bummer: there was an error!');
          // alert('errore1111 !!');
        },
    });
    return false;
}



 //setInterval(function(){ 
      //     getSuccessmessage();
        //}, 1000);
</script>
<!-- /******************************comment end ***************************************/ -->

<!-- /******************************scrolll ***************************************/ -->

<script type="text/javascript">
    $(function(){
  
        
       $('.div_wrapper').slimscroll({
        height: '250px'
      }).parent().css({
        background: '#237FAD',
        border: '2px dashed #184055'
      });


    });
</script>


<script type="text/javascript">
    $(function(){
     
        $('.chat_process').slimscroller({
        height: '250px'
      }).parent().css({
        background: '#237FAD',
        border: '2px dashed #184055'
      });


    });
</script>
<!-- <script type="text/javascript">

  //enable syntax highlighter
  prettyPrint();

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-3112455-22']);
  _gaq.push(['_setDomainName', 'none']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script> -->



